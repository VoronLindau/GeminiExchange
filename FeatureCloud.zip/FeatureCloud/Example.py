import pandas as pd

class FeatureModel:
    """Verwaltet die Features und die Regeln (Constraints) des Variantenmodells."""

    def __init__(self, name):
        self.name = name
        self.features = {}
        self.constraints = []

    def add_feature(self, name, optional=True):
        if name not in self.features:
            self.features[name] = {'optional': optional}

    def add_constraint(self, source_feature, target_feature, constraint_type='requires'):
        constraint = {'source': source_feature, 'target': target_feature, 'type': constraint_type}
        self.constraints.append(constraint)
        
    def load_from_excel(self, filename):
        """Lädt Features und Constraints aus einer Excel-Datei."""
        print(f"INFO: Lade Modell aus '{filename}'...")
        df_features = pd.read_excel(filename, sheet_name='Features')
        for _, row in df_features.iterrows():
            self.add_feature(row['Name'], row['Optional'])
        print(f"INFO: {len(self.features)} Features geladen.")

        df_constraints = pd.read_excel(filename, sheet_name='Constraints')
        for _, row in df_constraints.iterrows():
            self.add_constraint(row['Source'], row['Target'], row['Type'])
        print(f"INFO: {len(self.constraints)} Constraints geladen.")

    def validate_configuration(self, configuration):
        """Überprüft, ob eine Konfiguration gültig ist (jetzt mit 'OR'-Logik)."""
        print("\n" + "="*30)
        print(f"VALIDIERE KONFIGURATION: {configuration}")
        config_set = set(configuration)

        for constraint in self.constraints:
            source = constraint['source']
            target = constraint['target']
            constraint_type = constraint['type']

            if constraint_type == 'requires' and source in config_set and target not in config_set:
                print(f"FEHLER: '{source}' benötigt '{target}'.")
                return False
            
            elif constraint_type == 'excludes' and source in config_set and target in config_set:
                print(f"FEHLER: '{source}' und '{target}' schließen sich gegenseitig aus.")
                return False

            # *** NEUE LOGIK FÜR 'requires_one_of' ***
            elif constraint_type == 'requires_one_of' and source in config_set:
                # Teile die erlaubten Ziele am Komma auf
                possible_targets = {t.strip() for t in target.split(',')}
                # Prüfe, ob es eine Schnittmenge zwischen den erlaubten Zielen und der Konfiguration gibt
                if not config_set.intersection(possible_targets):
                    print(f"FEHLER: '{source}' benötigt eine der folgenden Optionen: {possible_targets}.")
                    return False

        print("ERGEBNIS: Diese Konfiguration ist GÜLTIG.")
        return True
    
if __name__ == "__main__":
    # --- Anwendung des Modells ---

    # 1. Leeres Feature-Modell erstellen
    mtb_modell = FeatureModel("Mountainbike Konfigurator")

    # 2. Modell aus der Excel-Datei füllen
    mtb_modell.load_from_excel('konfiguration_mountainbike.xlsx')

    # 3. Konfigurationen validieren

    # Beispiel 1: Gültig (Scheibenbremse mit passender Felge)
    config1 = ["Shimano Schaltung", "Scheibenbremse", "Felge_fuer_Scheibenbremse"]
    mtb_modell.validate_configuration(config1)

    # Beispiel 2: Gültig (Felgenbremse mit universeller Felge)
    config2 = ["SRAM Schaltung", "Felgenbremse", "Felge_fuer_Beides"]
    mtb_modell.validate_configuration(config2)

    # Beispiel 3: Ungültig (Scheibenbremse mit falscher Felge)
    config3 = ["SRAM Schaltung", "Scheibenbremse", "Felge_fuer_Felgenbremse"]
    mtb_modell.validate_configuration(config3)

    # Beispiel 4: Ungültig (zwei Schaltungstypen)
    config4 = ["SRAM Schaltung", "Shimano Schaltung", "Scheibenbremse", "Felge_fuer_Scheibenbremse"]
    mtb_modell.validate_configuration(config4)

