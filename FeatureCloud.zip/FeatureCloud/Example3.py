
import pandas as pd

class FeatureModel:
    """
    Verwaltet ein hierarchisches Feature-Modell mit Wahlgruppen und liest
    die Konfiguration aus einer Excel-Datei.
    Wandelt Spaltennamen automatisch in Kleinbuchstaben um, um Fehler zu vermeiden.
    """

    def __init__(self, name):
        self.name = name
        self.features = {}
        self.tree = {}
        self.constraints = []

    def load_from_excel(self, filename):
        """
        Lädt das gesamte Modell aus der Excel-Datei.
        Wandelt Spaltennamen in Kleinbuchstaben um.
        """
        print(f"INFO: Lade Modell aus '{filename}'...")
        
        # Lese Features
        df_features = pd.read_excel(filename, sheet_name='Features').where(pd.notna, None)
        # *** KORREKTUR: Spaltennamen in Kleinbuchstaben umwandeln ***
        df_features.columns = df_features.columns.str.lower()
        
        for _, row in df_features.iterrows():
            name = row['name'] # jetzt kleingeschrieben
            parent = row['parent']
            self.features[name] = {
                'Parent': parent,
                'Optional': bool(row['optional']),
                'GroupType': row['grouptype']
            }
            if parent:
                if parent not in self.tree:
                    self.tree[parent] = []
                self.tree[parent].append(name)

        # Lese die Constraints
        df_constraints = pd.read_excel(filename, sheet_name='Constraints').where(pd.notna, None)
        # *** KORREKTUR: Spaltennamen in Kleinbuchstaben umwandeln ***
        df_constraints.columns = df_constraints.columns.str.lower()
        
        for _, row in df_constraints.iterrows():
            self.constraints.append(row.to_dict())
            
        print("INFO: Modell erfolgreich geladen.")

    def validate_configuration(self, configuration):
        """
        Validiert eine gegebene Konfiguration gegen alle Regeln des Modells.
        """
        print("\n" + "="*40)
        print(f"VALIDIERE KONFIGURATION: {configuration}")
        config_set = set(configuration)

        for feature_name in config_set:
            if feature_name in self.tree:
                children = self.tree[feature_name]
                feature_details = self.features[feature_name]

                if feature_details.get('GroupType') == 'alternative':
                    ausgewaehlte_kinder = config_set.intersection(children)
                    if len(ausgewaehlte_kinder) != 1:
                        print(f"FEHLER: Für die alternative Gruppe '{feature_name}' muss genau eine Option gewählt werden.")
                        print(f"       Verfügbar: {children}")
                        print(f"       Gewählt: {list(ausgewaehlte_kinder)}")
                        return False

                for child in children:
                    if not self.features[child]['Optional'] and child not in config_set:
                        print(f"FEHLER: '{feature_name}' wurde gewählt, aber die Pflicht-Komponente '{child}' fehlt.")
                        return False

        for constraint in self.constraints:
            # Hier greifen wir jetzt auf die korrekten, kleingeschriebenen Schlüssel zu
            source = constraint['source']
            target = constraint['target']
            constraint_type = constraint['type']

            if constraint_type == 'requires_one_of' and source in config_set:
                possible_targets = {t.strip() for t in str(target).split(',')}
                if not config_set.intersection(possible_targets):
                    print(f"FEHLER: '{source}' benötigt eine der folgenden Optionen: {possible_targets}.")
                    return False
            
            elif constraint_type == 'excludes' and source in config_set and target in config_set:
                print(f"FEHLER: '{source}' und '{target}' schließen sich gegenseitig aus.")
                return False

        print("ERGEBNIS: Diese Konfiguration ist GÜLTIG. ✅")
        return True
    

if __name__ == "__main__":
    # --- Anwendung des Modells ---

    # 1. Leeres Feature-Modell erstellen
    mtb_modell = FeatureModel("Mountainbike Konfigurator")

    # 2. Modell aus der Excel-Datei füllen
    mtb_modell.load_from_excel('konfiguration_mountainbike3.xlsx')

        
    # --- 3 KORREKTE KONFIGURATIONEN ---
# --- 3 KORREKTE KONFIGURATIONEN ---

    # Testfall 1: Standard Hardtail (Größe L, Starre Stütze)
    config_ok_1 = [
        "Mountainbike", "Bike_Typ", "Hardtail",
        "Rahmengroesse", "L",
        "Sattelstuetze", "Starr",
        "Starrer_Rahmen",
        "Federgabel_Travel_Hardtail", "150mm_ht",
        "Bremsanlage", "SRAM_Code_Scheibenbremse",
        "Laufrad_Typ", "Laufrad_fuer_Scheibenbremse",
    ]

    # Testfall 2: High-End Fully (Größe M, 140mm Vario-Stütze)
    config_ok_2 = [
        "Mountainbike", "Bike_Typ", "Fully",
        "Rahmengroesse", "M",
        "Sattelstuetze", "Vario_140mm",
        "Viergelenk_Rahmen", "Hinterbaudämpfer_180mm",
        "Federgabel_Travel_Fully", "160mm_f",
        "Bremsanlage", "SRAM_Code_Scheibenbremse",
        "Laufrad_Typ", "Laufrad_fuer_Beides",
    ]

    # Testfall 3: Hardtail mit Felgenbremse (Größe S, 100mm Vario-Stütze)
    config_ok_3 = [
        "Mountainbike", "Bike_Typ", "Hardtail",
        "Rahmengroesse", "S",
        "Sattelstuetze", "Vario_100mm",
        "Starrer_Rahmen",
        "Federgabel_Travel_Hardtail", "140mm_ht",
        "Bremsanlage", "Magura_Felgenbremse",
        "Laufrad_Typ", "Laufrad_fuer_Felgenbremse",
    ]


    # --- 4 FEHLERHAFTE KONFIGURATIONEN ---

    # Testfall 4: Hardtail mit verbotenem Hinterbaudämpfer
    config_fehler_1 = [
        "Mountainbike", "Bike_Typ", "Hardtail",
        "Rahmengroesse", "M",
        "Sattelstuetze", "Starr",
        "Hinterbaudämpfer_180mm",  # Verboten für Hardtail!
        "Starrer_Rahmen",
        "Federgabel_Travel_Hardtail", "140mm_ht",
        "Bremsanlage", "SRAM_Code_Scheibenbremse",
        "Laufrad_Typ", "Laufrad_fuer_Scheibenbremse",
    ]

    # Testfall 5: Fully mit Scheibenbremse aber falschem Laufrad
    config_fehler_2 = [
        "Mountainbike", "Bike_Typ", "Fully",
        "Rahmengroesse", "L",
        "Sattelstuetze", "Vario_120mm",
        "Viergelenk_Rahmen", "Hinterbaudämpfer_180mm",
        "Federgabel_Travel_Fully", "150mm_f",
        "Bremsanlage", "SRAM_Code_Scheibenbremse",
        "Laufrad_Typ", "Laufrad_fuer_Felgenbremse", # Widerspruch!
    ]

    # Testfall 6: Hardtail mit verbotener 160mm Federgabel
    config_fehler_3 = [
        "Mountainbike", "Bike_Typ", "Hardtail",
        "Rahmengroesse", "XL",
        "Sattelstuetze", "Vario_180mm",
        "160mm_f", # Verbotene Gabel für Hardtail!
        "Starrer_Rahmen",
        "Federgabel_Travel_Hardtail", "140mm_ht",
        "Bremsanlage", "SRAM_Code_Scheibenbremse",
        "Laufrad_Typ", "Laufrad_fuer_Scheibenbremse",
    ]

    # Testfall 7 (aus deinem config_fully_korrekt): Korrekt
    config_fully_korrekt = [
        "Mountainbike", "Bike_Typ", "Fully",
        "Rahmengroesse", "L",
        "Sattelstuetze", "Vario_180mm",
        "Viergelenk_Rahmen", "Hinterbaudämpfer_180mm",
        "Federgabel_Travel_Fully", "160mm_f",
        "Bremsanlage", "SRAM_Code_Scheibenbremse",
        "Laufrad_Typ", "Laufrad_fuer_Beides",
    ]

    # --- 2 NEUE TESTFÄLLE ---

    # Testfall 8: Ungültig - Vario 180mm Stütze bei Rahmengröße S
    config_fehler_s_180 = [
        "Mountainbike", "Bike_Typ", "Fully",
        "Rahmengroesse", "S",                  # Zu kleiner Rahmen
        "Sattelstuetze", "Vario_180mm",         # Zu große Stütze -> FEHLER!
        "Viergelenk_Rahmen", "Hinterbaudämpfer_180mm",
        "Federgabel_Travel_Fully", "140mm_f",
        "Bremsanlage", "SRAM_Code_Scheibenbremse",
        "Laufrad_Typ", "Laufrad_fuer_Scheibenbremse",
    ]

    # Testfall 9: Gültig - Fully in Rahmengröße S mit passender Stütze
    config_ok_fully_s = [
        "Mountainbike", "Bike_Typ", "Fully",
        "Rahmengroesse", "S",                  # Gültige Rahmengröße
        "Sattelstuetze", "Vario_140mm",         # Passende Stütze
        "Viergelenk_Rahmen", "Hinterbaudämpfer_180mm",
        "Federgabel_Travel_Fully", "140mm_f",
        "Bremsanlage", "SRAM_Code_Scheibenbremse",
        "Laufrad_Typ", "Laufrad_fuer_Scheibenbremse",
    ]


    # Diese Konfiguration wird jetzt als GÜLTIG erkannt.
    mtb_modell.validate_configuration(config_fully_korrekt)


    # Alle Konfigurationen validieren
    print("--- START DER VALIDIERUNG ---")
    mtb_modell.validate_configuration(config_ok_1)
    mtb_modell.validate_configuration(config_ok_2)
    mtb_modell.validate_configuration(config_ok_3)
    mtb_modell.validate_configuration(config_fehler_1)
    mtb_modell.validate_configuration(config_fehler_2)
    
    # Alle neuen Konfigurationen validieren
    print("--- START DER WEITEREN VALIDIERUNG ---")
    mtb_modell.validate_configuration(config_fehler_3)

    # --- VALIDIERUNG ---
    # Annahme: mtb_modell wurde bereits geladen
    mtb_modell.validate_configuration(config_fehler_s_180)
    mtb_modell.validate_configuration(config_ok_fully_s)
